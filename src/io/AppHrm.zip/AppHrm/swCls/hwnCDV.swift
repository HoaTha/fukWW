//
//  hwnCDV.swift
//  AppHrm
//
//  Created by Administrator on 09/01/2024.
//

import Foundation

class Car {
    class var countryOfProduction: String { "Japan" }
    class var topSpeed: Float { 100.0 }
}

class SuperFastCar: Car {
    override class var countryOfProduction: String { "Italy" }
    override class var topSpeed: Float { 250.0 }
}
