//
//  TcpSocket.swift
//  AppHrm
//
//  Created by Administrator on 09/01/2024.
//
//https://developer.apple.com/forums/thread/84472
//https://forums.developer.apple.com/forums/thread/120486


//https://forums.developer.apple.com/forums/thread/705328
//https://gist.github.com/ruurdadema/8954b39853b97babed6c62297712b1af

//https://forums.developer.apple.com/forums/thread/116723


import Foundation
import Network

protocol NetworkConnectionDelegate: AnyObject
{
    func connectionOpened(connection: NetworkConnection)
    func connectionClosed(connection: NetworkConnection)
    func connectionError(connection: NetworkConnection, error: Error)
    func connectionReceivedData(connection: NetworkConnection, data: Data)
}

class NetworkConnection
{
    private static var nextID: Int = 0
    
    weak var delegate: NetworkConnectionDelegate?
    private let nwConnection: NWConnection
    let id: Int
    private var queue: DispatchQueue?
    
    
    private var aCDV:NSArray
    
    init(nwConnection: NWConnection,_ CDV: NSArray)
    {
        self.nwConnection = nwConnection
        self.id = NetworkConnection.nextID
        NetworkConnection.nextID += 1
        self.aCDV=CDV;
    }
    
    func start(queue: DispatchQueue)
    {

        self.queue = queue
        self.nwConnection.stateUpdateHandler = self.onStateDidChange(to:)
        self.nwConnection.viabilityUpdateHandler = viabilityUpdateHandler(to:)
        self.doReceive(self.aCDV)
        //self.receiveTCP()
        self.nwConnection.start(queue: queue)
    }

    func send()
    {
        let msg="HOLO /connect?cmd=1"
        
        let data = Data("\(msg)".utf8)
        //let data = msg.data(using: String.Encoding.utf8)!
        
        //let data = Data((.utf8))
        let sizePrefix = withUnsafeBytes(of: UInt16(data.count).bigEndian) { Data($0) }
        
        //var bytes = [UInt8](repeating: 0, count: 1000)
    
        //let err = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
    

                
       print("Send \(data.count) bytes")
        
        self.nwConnection.send(content: data,isComplete: true, completion: .contentProcessed( { error in
            if let error = error {
                self.delegate?.connectionError(connection: self, error: error)
                return
            }
        }))
        
    /*
        self.nwConnection.batch {
            /*
            self.nwConnection.send(content: sizePrefix, completion: .contentProcessed( { error in
                if let error = error {
                    self.delegate?.connectionError(connection: self, error: error)
                    return
                }
            }))
             */
            
            self.nwConnection.send(content: data, completion: .contentProcessed( { error in
                if let error = error {
                    self.delegate?.connectionError(connection: self, error: error)
                    return
                }
            }))
        }
     */
    }
    
    func viabilityUpdateHandler(to state: Bool){
        if (state) {
            NSLog("Connection is viable")
            //myport = portForEndpoint((connection?.currentPath?.localEndpoint)!)!
            //print(String(describing: myport))
            //server()

            
        } else {
            NSLog("Connection is not viable")
        }
    }

    private func onStateDidChange(to state: NWConnection.State)
    {
        switch state {
            case .setup:
                break
            case .waiting(let error):
                self.delegate?.connectionError(connection: self, error: error)
            case .preparing:
                break
            case .ready:

            


                self.delegate?.connectionOpened(connection: self)
            
            self.send();
            
            case .failed(let error):
            
                self.delegate?.connectionError(connection: self, error: error)
            case .cancelled:
                break
            default:
                break
        }
    }

    func close()
    {
        self.nwConnection.stateUpdateHandler = nil
        self.nwConnection.cancel()
        delegate?.connectionClosed(connection: self)
    }
    
    func part_DEV(_ line:String) -> [String] {
        
        let value = 4
        // Convert Int to a UnicodeScalar.
        let u = UnicodeScalar(value)!
        // Convert UnicodeScalar to a Character.
        let char = Character(u)
        
        let msg=line.components(separatedBy:  String(char))
        
        return msg;
        
        //String[] msg=line.split(String.valueOf((char) 4));
        //return [1, 2, 3]
    }
    
    func receiveTCP()
        {
            self.nwConnection.receiveMessage{ (data, context, isComplete, error) in
                
                print("Receive is complete")
                if (data != nil)
                {
                    let backToString = String(decoding: data!, as: UTF8.self)
                    print("Received message: \(backToString)")
                }
                else
                {
                    print("Data == nil")
                }
                
                
                if (isComplete)
                {
                    
                }
                else
                {
                    self.receiveTCP()
                }
            }
        }

    
    private func doReceive(_ CDV: NSArray){
        /*
        self.nwConnection.receiveMessage { data, context, isComplete, error in
                 if let unwrappedError = error {
                     print("Error: NWError received in \(#function) - \(unwrappedError)")
                     return
                 }

                 guard isComplete, let data = data else {
                     print("Error: Received nil Data with context - \(String(describing: context))")
                     return
                 }
                 //self.messageReceived = data

                 print(String(decoding: data, as: UTF8.self))

                 if String(decoding: data, as: UTF8.self) == "teststring" {
  


                 }
                                         
                 //if self.listening {
                 //    self.receive()
                 //}
                 
                 //print(String(self.listening))
             }
         */
        self.nwConnection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { (sizePrefixData, context, isComplete, error) in
            
  
                if let data = sizePrefixData, !data.isEmpty
                {
                    let stringData = String(data: data, encoding: .utf8)
                    print(stringData)
                    /*
                    self.part_DEV(stringData!)
                    
                    var  js = String(format: "dopostqueue['%@']('CON CAT TAO NHAN DUOC ROI NHE')",CDV[4] as! String)
                    print(js)
                    //self.delegate?.extraFunc()
                    
                    DispatchQueue.main.async {
                        let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate
                        appDelegate?.evalJsHelper2(js)
                    }
                     */
                    
                    if self.nwConnection.state == .ready && isComplete == false {
                        self.doReceive(CDV)
                    }
                    
       
                    
                    //self.delegate?.connectionReceivedData(connection: self, data: data)
                    
                    
                }


        }
     
    }
    private func doReceivex()
    {
        self.nwConnection.receive(minimumIncompleteLength: MemoryLayout<UInt16>.size, maximumLength: MemoryLayout<UInt16>.size) { (sizePrefixData, context, isComplete, error) in
            var sizePrefix: UInt16 = 0
            
            

            

            // Decode the size prefix
            if let data = sizePrefixData, !data.isEmpty
            {
                

                
                
                //let byteArray: [UInt8] = data.map { $0 }
                
                //let backToString = String(decoding: data, as: UTF8.self)

                let str = String(data:data, encoding: .utf8)
                
                print(data as NSData)
                
                sizePrefix = data.withUnsafeBytes
                {
                    $0.bindMemory(to: UInt16.self)[0].bigEndian
                }
                //let str = String(decoding: data.withUnsafeBytes(<#T##body: (UnsafeRawBufferPointer) throws -> ResultType##(UnsafeRawBufferPointer) throws -> ResultType#>), as: UTF8.self)
    
                print("Received:", String(data: data, encoding: .utf8) )
                let stringData = String(data: data, encoding: .utf8)
                let datax = stringData!.data(using: .utf8)
                //do {
                //    let json = try JSONSerialization.jsonObject(with: datax!, options: .mutableContainers) as! [String:Any]
                //    print("REsponseeeeData",json)
                //}catch{
                   
                //}
                
                
            }
            
            if isComplete
            {
                self.close()
            }
            else if let error = error
            {
                self.delegate?.connectionError(connection: self, error: error)
            }
            else
            {
                // If there is nothing to read
                if sizePrefix == 0
                {
                    print("Received size prefix of 0")
                    //self.doReceive()
                    return
                }
                
               
                print("Read \(sizePrefix) bytes: " )
                
                // At this point we received a valid message and a valid size prefix
        /*
                self.nwConnection.receive(minimumIncompleteLength: Int(sizePrefix), maximumLength: Int(sizePrefix)) { (data, _, isComplete, error) in
                    if let data = data, !data.isEmpty
                    {
                        

                        
                        
                        self.delegate?.connectionReceivedData(connection: self, data: data)
                    }
                    if isComplete
                    {
                        self.close()
                    }
                    else if let error = error
                    {
                        self.delegate?.connectionError(connection: self, error: error)
                    }
                    else
                    {
                        self.doReceive()
                    }
                }
              */
            }
        }
    }
    
    
    
}
