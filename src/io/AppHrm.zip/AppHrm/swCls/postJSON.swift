//
//  postJSON.swift
//  AppHrm
//
//  Created by Administrator on 11/01/2024.
//
import UIKit
import Foundation
import CryptoSwift

class postJSON {
    
    static let  SECRET_KEY:String = "aesEncryphieuKey"
    //https://stackoverflow.com/questions/40123319/easy-way-to-encrypt-decrypt-string-in-android
    static let  INIT_VECTOR:String = "encryphieuIntVec"
    
    

    
    public static func decrypt(_ value:String , _ CUS:String...) -> String{
        do {
            
            //Convert base64 to Buffer
            let base64data = value.base64ToByteArray()
            let iv=Array<UInt8>((CUS.count>0 ? CUS[0]:INIT_VECTOR).utf8)//Array(<Your key>.utf8)
                                
            let skeySpec=Array<UInt8>((CUS.count>1 ? CUS[1]:SECRET_KEY).utf8)//Array(<Your key>.utf8)

            let data =  value.base64ToByteArray()!
            let decrypted = try! AES(key: skeySpec, blockMode: CBC.init(iv: iv), padding:.pkcs7).decrypt(data)
            
            let decryptedData = Data(decrypted)
            
            return String(bytes: decryptedData.bytes, encoding: .utf8) ?? "Could not decrypt"
            

            /*
            //https://gist.github.com/delasign/5f26993b3e97231a7b4b088d5321f327
            //var decrypted = try! AES (key: skeySpec, blockMode: CTR(iv: iv), padding: .zeroPadding).decrypt(base64data!)// decrypt buffer
            // convert decrypted buffer to data
            //clairMessage = String(bytes: decrypted, encoding: .utf8)
            
            
            
            return  clairMessage!;
            
            
      
            //postJSON.decrypt(org,iv ,SECRET);
            let iv:IvParameterSpec  = new IvParameterSpec((CUS.length>0 ?CUS[0]: INIT_VECTOR).getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec((CUS.length>1 ?CUS[1]:SECRET_KEY).getBytes("UTF-8"), "AES");

            //https://jaysojitra13.medium.com/cross-platform-encryption-and-decryption-using-android-ios-angular-noejs-38bc4f75eaf6
            Cipher cipher = Cipher.getInstance(CUS.length>2 ?CUS[2]:"AES/CBC/PKCS7Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] original = cipher.doFinal(Base64.decode(value, Base64.DEFAULT));

            return new String(original);
             */
            
        } catch {
            print("Could not decrypt: \(error)")
        }
        return ""
    }
    
 
    
}
