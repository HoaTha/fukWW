//
//  Contents.swift
//  AppHrm
//
//  Created by Administrator on 09/01/2024.
//https://github.com/R1no933/ThreadTask/blob/main/ThreadTask.playground/Sources/Chip.swift

import Foundation
import UIKit

//Working thread
class _Work: Thread {
    
    private var stash: Stash
    private var count: Int=0
    
    init(stash: Stash, count: Int) {
        self.stash = stash
        self.count = count
    }
    
    override func main() {
        working()
        print("Thread đang chạy đã kết thúc")
    }
    
    private func working() {
        while count != 0 {
            if stash.chipArray.isEmpty == false {
                count += 1
                stash.chipArray.last?.sodering()
                print("Con chip được hàn.")
                stash.chipArray.removeLast()
                print("Đã xóa chip khỏi ngăn xếp.")
                print("còn lại: \(stash.getAllChips()).")
            }
        }
    }
}

// Chip Generator thread
class _Generator: Thread {
    
    private var stash: Stash
    private var count: Int=0
    private var interval: Double=0
    
    init(stash: Stash, count: Int, interval: Double) {
        self.stash = stash
        self.count = count
        self.interval = interval
    }
    
    override func main() {
        for _ in 1...count {
            addChip()
        }
        cancel()
        print("Tạo chủ đề đã hoàn tất")
    }
    
    private func createChip() -> Chip {
        let chip = Chip.make()
        print("Loại chip\(chip.chipType) tạo. còn lại: \(stash.getAllChips())")
        return chip
    }
    
    public func addChip(){
        let chip = createChip()
        stash.pushChip(chip: chip)
        Thread.sleep(forTimeInterval: interval)
    }
}

//Stash class
class Stash {
    var chipArray: [Chip] = []
    private var queue: DispatchQueue = DispatchQueue(label: "syncQueue", qos: .utility, attributes: .concurrent)
    var count: Int { chipArray.count }
    

    func pushChip(chip: Chip) {
        queue.async(flags: .barrier) { [unowned self] in
            self.chipArray.append(chip)
            print("Loại chip \(chip.chipType) đang được xử lý. còn lại: \(getAllChips())")
        }
    }
    
    func popChip() -> Chip? {
        var chip: Chip?
        queue.sync { [unowned self] in
            guard let poppedChip = self.chipArray.popLast() else { return }
            chip = poppedChip
            print("Loại chip \(poppedChip.chipType) chuẩn bị. còn lại: \(getAllChips())")
        }
        
        return chip
    }
    
    func getAllChips() -> [UInt32] {
        chipArray.compactMap { $0.chipType.rawValue }
    }
}



