//
//  connThread.swift
//  AppHrm
//
//  Created by Administrator on 11/01/2024.
//


import Socket

class connThread {
    
    let port: Int32
    let host: String
    let socket: Socket
    //var cdvArg: NSArray
    
    func connect(handler: (_ socket: Socket) -> Void) throws {
        //host: "192.168.1.201" ,port: port
        do {
            try socket.connect(to: host, port: port)

        } catch {
            print("socket client error: \(error)")
            socket.close()
        }
        //
        handler(socket)
        //
    }

    var rawREQ:[String]
    var OCL:[String]=[]
    
    var step:String="";
    func CMD (_  line:String )-> String{

        switch (step) {
        case "connect":
            
            let dbk:[String]=self.part_DEV(line)
            
            //if (MAC.equals(dbK[6]) && SN.equals(dbK[7])){
            //
            //
            if (rawREQ[5].elementsEqual("")) {return  "0"}
            //starting the thread
            MainApplication.atthwnd?.child_CALL(self)//msg2_PAPA()//if (!liveLIST.contains(this))liveLIST.add(this);
            //
            //
            MainApplication.atthwnd?.load_DEV_info(2,rawREQ);//add
            //
            return rawREQ[5];
            
        case "disconn"://2

            return  "0";

        case "ATT_LOG":

            let msg:[String]=line.spli(Txt.ascii2S(4))
            var ln:String=line

            if (msg[0].elementsEqual("END_LOG")){

                step="online";

                //Log.i("DUME_SOCKET", rawREQ[7]);

                //String rst=new String(bunzip2(Base64.decode(rawREQ[7], 0)));
                //https://stackoverflow.com/questions/7454330/how-to-remove-newlines-from-beginning-and-end-of-a-string
                //return "ATT_LOG" + String.valueOf((char) 4) + rst.replaceAll("\\R", "_");

                return "ATT_LOG" + Txt.ascii2S(4) + rawREQ[7];

                //runAsRoot();
            }else {
                rawREQ[7]+=line;
                //*** Cannot assign to value: 'line' is a 'let' constant
                ln="WAI___NXT___LN"
            }
            //*** chu y, ben android gan nhung ko phai byref !!!!
            return  ln;
            //
        case "online":
            
            let msg:[String]=line.spli(Txt.ascii2S(4) )
            var ln:String=line

            if (msg[0].elementsEqual("RTEVT_STA")){

                if (MainApplication.RTEV(rawREQ)>0){
                  //
                  RTEVT(msg);
                  //
                  //postJSON.incomeSignal();
                  //
                }

            }else if (msg[0].elementsEqual("ATT_LOG")){
                step=msg[0]
                rawREQ[7]=msg[1]
                //*** Cannot assign to value: 'line' is a 'let' constant
                ln="WAI___NXT___LN"//line="WAI___NXT___LN";
            }else{
              
            }
            //*** chu y, ben android gan nhung ko phai byref !!!!
            return ln;

        case "reconnect":
    
            self.part_DEV(line);


            //************************************************
            if (rawREQ[5].elementsEqual("")) {
                return  String("0")
            }
            //starting the thread
            MainApplication.atthwnd?.child_CALL(self)//msg2_PAPA()//if (!liveLIST.contains(self)) liveLIST.append(self);
            //************************************************
            //
            //tinh lai bubble dich vu realtime
            //isNOTI(RTEV(rawREQ)>0);
            //
            //
            //
            rawREQ[2]="online";
            step="online";

            return "CONN_STA" + Txt.ascii2S(4)  + "online" + Txt.ascii2S(4) + rawREQ[5]   ;

                
        
        default:
            print("Unknown event")
        }
        
        return ""

    }
    
    func  RTEVT(_ msg:[String]){
        MainApplication.playAudioAsset("apply_incoming")
    }
    
    /*
    func msg2_PAPA(){
        DispatchQueue.main.async {
            //
            let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate

            //
        }
    }
     */
               

    init(_ rawREQ:[String]) throws {
        
        //self.cdvArg=cdvArg
        
        self.rawREQ=rawREQ//cdvArg.compactMap({ $0 as? String })
        
        self.host=rawREQ[0]
        
        self.port=11222
        
        self.socket = try Socket.create()
        
    }


    
    
    func OCL_BUILDER(_ moi:String ,_ dbK_4:String ) -> [String]{
        //build cac thong so interger giong nhu hihrs
        var OCL:[String]=dbK_4.substring(1..<dbK_4.length-1).spli(",");//OCL=dbK_4.substring(1,dbK_4.length()-1).split(",",-1);
        //
        let rawREQ_4:[String]=moi.substring(1..<moi.length-1).spli(",");//String[] rawREQ_4 =moi.substring(1,moi.length()-1).split(",",-1);
        
        for i in 0 ..< rawREQ_4.count {
            OCL[i]=rawREQ_4[i];
        }
        
        return OCL;
    }
    
    func GIAI_MA(_ org:String) ->String{
        let SECRET:String  = "My32charPasswordAndInitVectorStr"//must be 32 char length
        let iv:String=SECRET.substring(0..<16)
        //https://jaysojitra13.medium.com/cross-platform-encryption-and-decryption-using-android-ios-angular-noejs-38bc4f75eaf6
        return postJSON.decrypt(org,iv ,SECRET,"AES/CBC/NoPadding")
    }
    
    func part_DEV(_ line:String) -> [String] {
        
        var msg=line.spli( Txt.ascii2S(4))//.components(separatedBy:  Txt.ascii2S(4))
        
        //-1 after split will keep all null item ....
        var dbK = msg[7].spli(";");//old msg[7]
        //
        //
        //String org = dbK[1].replaceAll("_", "/").replaceAll("-", "+");
        let org:String = dbK[1].replacingOccurrences(of: "_", with: "/").replacingOccurrences(of: "-", with: "+")
        //
        //
        var RAW:String=GIAI_MA(org);
        
        //dao thu tu thong tin
        let mark:String=RAW.substring(0..<3);
        RAW=RAW.substring(from:3);//please remove 3 char mark !
        //
        //
        let TOK:[String]=RAW.replacingOccurrences(of:"\n",with: "").spli(Txt.ascii2S(29));
        //
        var RST:[String] = TOK.map { $0 };//ArrayList<String> RST= new ArrayList<String>(Arrays.asList(TOK));
        //
        for i in 0 ..< mark.length {
            let c = Int(String(mark.character(i))) ?? 0
            RST[c]=TOK[i]
        }
        //
        //lay duoc seri no ...
        let SN:String=RST[0];
        let MAC:String=msg[6].spli("=")[1]//String MAC= msg[6].split("=")[1];//.replaceAll(":","")

        OCL=OCL_BUILDER(rawREQ[4],dbK[4]);
        
        dbK[4]="[" + OCL.joined(separator: ",")  + "]";//postJSON.fukJOIN(OCL,",")
        //array.joined(separator: ", ")
        
        
        //4000TID ko lay duoc SN
        if (dbK[7].length<5) {
            dbK[7]=SN;
        };
        //
        //current user ben hihrs de temp o index 2; cmd=
        dbK[8]=msg[2].spli("=")[1]
        //
        msg[7]=dbK.joined(separator:";") //postJSON.fukJOIN(dbK,";");
        //
        //
        rawREQ[4] = dbK[4];//OCL from hihrs
        rawREQ[5] = msg[7];//security key
        rawREQ[10]=dbK[10] ;//exwdms USE LOCAL MODE //device base 64
        //
        return dbK;
        //
    }
    
    func DEV_CMD(_ args:[String],_ rawREQ:[String]) ->String{
        
        switch (args[4]){
            case "-505"://CMD_ATTLOG_RRQ      13

                var dogZK:[String]=rawREQ[10].spli("-")

                //String QRY=
                var RAW:String=GIAI_MA(args[5]).replacingOccurrences(of: "\u{1D}", with: "")//.replaceAll("[\\p{Cntrl}]", "");
                var reINF:[String]=args[6].spli("|");
                //
 
                if (dogZK[0].elementsEqual("0")){
                    dogZK=RAW.spli("busybox base64")
                    RAW=dogZK[0] + "uuencode -m - | sed -e '${/^=/d}' -e '1{/begin-/d}'" + dogZK[1]
                }
                //
                //
                var block:Int=Int(reINF[1])!
                let W:String=" Where ID!=-1"
                var _X:String=reINF[2] + "="//total record *** avloid X compare in C program
                //
 
                if (reINF[0].elementsEqual("0") ) {//lan dau tien
                    _X="X=\"SELECT count(*) FROM ATT_LOG" + W + "\" | sed '$!d'"
                    reINF[0]=W + " LIMIT " + String(block)
                    reINF[1]="OFFSET '$((X-" + String(block) + "))'"
                    reINF[2] = "'$X'"
                }else {
                    let remain:Int=Int(reINF[2])! - Int(reINF[4])!
                    reINF[0] = W + " LIMIT " + String(block < remain ? block : remain)
                    reINF[1] = "OFFSET " + String(remain - block)
                };
                //
    
                //them tong so record vao phia truoc voi dau ';'
                reINF[3]="-e '1s/^/'$X';/' -e '" + reINF[3]
                //
                let cmd:String=Txt.sformat(RAW,"%s",reINF)//String cmd= String.format(RAW,reINF);// "13=" + args[5] + "&a=" + args[6];
                //
  
                //Log.i("DUME_SOCKET", args[0] + " ; " +  args[6]);
                block=block*3000/500
                //
                //    return "-505=" + Uri.encode(cmd + "&sz=" + (block<4016?4016:block) + "&" + _X);//X="SELECT count(*) FROM ATT_LOG"
                var doggy:String=cmd + String("&sz=") + (block<4016 ? "4016" : String(block))  + "&" + _X
                doggy=doggy.urlEncoded()!
                //
                let fuck:String=String(format:"-505=%@",doggy)
                //
                return fuck
                //
            default:
                return  "cmd=" + args[4];
        }
    }

    
    func sendCMD(_ arg:String ){
        self.step=rawREQ[2]
        do {
            if (self.step=="disconn"){
                //
                MainApplication.atthwnd?.load_DEV_info(1,rawREQ);//remove
                //
                //
                //oSTRE.close();
                //input.close();
                
                socket.close();//ben Atthandler se sinh ra loi ,
                //-> chay thang xuong catch roi remove trong queue addNewDevice error_SOK (****)
                //
                //remove ra luon
                //error_SOK(1);
                
            }else{
                let msg="HOLO /" + self.step + "?" + arg
                try socket.write(from: msg)
            }
        }catch{
            
        }
    }
    
    
}

