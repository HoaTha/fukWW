//
//  AttHandler.swift
//  AppHrm
//
//  Created by Administrator on 11/01/2024.
//

import Socket

class AttHandler {
    
    var liveLIST = [connThread]();//ArrayList<connThread> liveLIST = new ArrayList<>();
    var dieSOCK=[[String]]()//ArrayList<String[]> dieSOCK= new ArrayList<>();
    
    static let quitCommand: String = "QUIT"
    static let shutdownCommand: String = "SHUTDOWN"
    static let bufferSize = 4096
    
    var continueRunningValue = true
    let socketLockQueue = DispatchQueue(label: "com.kitura.serverSwift.socketLockQueue")
    
    var continueRunning: Bool {
        set(newValue) {
            socketLockQueue.sync {
                self.continueRunningValue = newValue
            }
        }
        get {
            return socketLockQueue.sync {
                self.continueRunningValue
            }
        }
    }

    
    deinit {
        // Close all open sockets...
    }
    
    func run() {
        
        let queue = DispatchQueue.global(qos: .background)
        
        queue.async {
            do {

                print("Listening on att device ..")
                
                repeat {
                    //
                    for z in (0 ..< self.dieSOCK.count).reversed() {
                        //
                        var die:[String]=self.dieSOCK[z];
                        //
                        //bo ra co gi thi add lai
                        if let idx = self.dieSOCK.firstIndex(of: die) {
                            self.dieSOCK.remove(at: idx)
                        }
                        //
                        self.DO_CONN(&die,"reconnect");
                    }
                    //
                    print("liveLIST: \(self.liveLIST.count) -   dieSOCK: \(self.dieSOCK.count)")
                    //
                    sleep(5)
                    
                } while self.continueRunning
                
            }
            catch let error {

            }
        }
    }
    
    func child_CALL(_ child: connThread){
        //
        let dogLIV = liveLIST.contains { doggy in
            return doggy===child
        }
        //
        if (dogLIV==false){
            socketLockQueue.sync { [unowned self, child] in
                liveLIST.append(child)
            }
        }
    }
    

    
    func load_DEV_info(_ mod:Int,_ REQ:[String]){
        
        var _RTEV:Int=0;
        var lstMCC:[String]=TinyDB.getListString("lst__MCC" + MainApplication.firebase_topic)
        //
        for z in (0 ..< lstMCC.count).reversed() {
            //
            let dev:String=lstMCC[z];
            if (dev.contains(REQ[0])){
                //update
                if let idx = lstMCC.firstIndex(of: dev) {
                    lstMCC.remove(at: idx)
                }
            }else {
                _RTEV+=MainApplication.RTEV(dev.spli(Txt.ascii2S(30)))
            }
        }
        //mod==3 global conn FCM msg
        if (mod==3 || (mod==2 && MainApplication.RTEV(REQ)>0)) {
            //1. lstMCC dung de load khi app run
            //2. ko can connect mcc khi ko co rtevet
                    lstMCC.append( REQ[0] + Txt.ascii2S(30) + REQ[1] + Txt.ascii2S(30) +

                                    (mod==3 ? REQ[2] :"reconnect") +

                        Txt.ascii2S(30) + "-1" +
                        Txt.ascii2S(30) + REQ[4] +
                        Txt.ascii2S(30) + "" + //index 5 , be carefull value "tinydb" cua global conn
                        Txt.ascii2S(30) + REQ[6] +//comkey
                        Txt.ascii2S(30) + "" + //du phong 7
                        Txt.ascii2S(30) + "" +//du phong 8
                        Txt.ascii2S(30) + "" +//du phong 9
                        Txt.ascii2S(30) + REQ[10] //du phong 10
                    )

            _RTEV+=1;

        }
        //
        lstMCC.removeAll() { $0 == "" }
        //TinyDB.putListString("lst__MCC" + MainApplication.firebase_topic,lstMCC)
        //
    }
    
    
    func RST_2_UI(_ js:String){
        DispatchQueue.main.async {
            let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate
            appDelegate?.evalJsHelper2(js)
        }
    }
    
    func INI_CONN(_ args:[String] ){
        //
        if (args[2].elementsEqual("fcmdev")) {
            return;
        }
        //
        for dog in (0 ..< liveLIST.count).reversed() {
            //ko co realtime
            let sT:connThread=liveLIST[dog];
            
            if (args[2].elementsEqual("dispose") ){
                if (MainApplication.RTEV(sT.rawREQ)==0){

                     sT.rawREQ[2]="disconn";

                     sT.rawREQ[3]="-1";//ko goi feedback ve UI???

                     sT.sendCMD("cmd=" + sT.rawREQ[4]);
                     //
                 }
            }else if (args[0].elementsEqual(sT.rawREQ[0])){ //compare ip
                //
                  if (args[2].elementsEqual("connect") || args[2].elementsEqual("reconnect")) {
                      //update lai window handle event args[3]
                      sT.rawREQ[3]=args[3];
                      //
                      sT.rawREQ[2]="online";
                      sT.step="online";
                      //
                      //tra ve lenh connect
                      var line:String=args[0] + Txt.ascii2S(3) + args[2]   + Txt.ascii2S(31)  + "CONN_STA" + Txt.ascii2S(4)   +  sT.step + Txt.ascii2S(4)   + sT.rawREQ[5]
                      //
                      line=String(format: "dopostqueue['%@']('%@')",args[3] ,line)
                      //
                      self.RST_2_UI(line)
                      //
                  }else{
                      //
                      //thuc thi lenh tiep theo ....
                      if (args[2].elementsEqual("devcmd")){
                          //
                          //device command tam thoi dung online ??
                          let FUK:String=sT.DEV_CMD(args, sT.rawREQ)
                          sT.sendCMD(FUK);
                          //
                      }else if (args[2].elementsEqual("edit")){
                          //
                          //build update OCL tron sT
                          sT.OCL=sT.OCL_BUILDER(args[4],sT.rawREQ[4]);
                          //
                          sT.rawREQ[4]="[" + sT.OCL.joined(separator:",") + "]";
                          modATT(args, sT.rawREQ);
                          //
                          //
                      }else{

                          sT.rawREQ[2]=args[2];
                          sT.sendCMD("cmd=" + sT.rawREQ[4]);
                      }
                      //
                  }
                  //thoat neu new reques connect tim thay.
                  return;
            }
                       
        }
        //
        for z in (0 ..< dieSOCK.count).reversed() {
            
            var raw:[String] = dieSOCK[z];
            
            if (args[2].elementsEqual("dispose") ) {
                //
                //ko co realtime
                //if (RTEV(raw) == 0) {
                //    dieSOCK.remove(raw);
                //}

            } else if (args[0].elementsEqual(raw[0]) && args[1].elementsEqual(raw[1])){
                //
                //handle window listen
                raw[3]=args[3];
                //
                if (args[2].elementsEqual("devcmd")){
                    //
                    var line:String=args[0] + Txt.ascii2S(3) + args[2]   + Txt.ascii2S(31) +
                            "CONN_STA" + Txt.ascii2S(4)  +  "offline" + Txt.ascii2S(4)  + String("0")
                    line=String(format: "dopostqueue['%@']('%@')",args[3] ,line)
                    //
                    self.RST_2_UI(line)
                    //
                    //device command tam thoi dung online ??
                    return;
                    //
                }else if (args[2].elementsEqual("edit")){
                    //
                    //raw[4]="[" + postJSON.fukJOIN(OCL_BUILDER(args[4],raw[4]),",") + "]";
                    //modATT(args,raw);
                    //
                    return;
                }
            }//end for z
        }
        //
        //
        if (args[2].elementsEqual("dispose") ){
            //
            if (dieSOCK.count==0 && liveLIST.count==0){
                //
                self.continueRunning = false
                MainApplication.atthwnd=nil//stop
                //
                //end luon service
                //isLOOP=false;
                //stopSelf();
            }
            //
           return;
        }
        //
        var iniA:[String]=args.map{$0}
        iniA.append("") // rawREQ[10]=dbK[10]  bi thieu
        //
        DO_CONN(&iniA ,args[2]);
        //
    }

    func DO_CONN(_ args: inout  [String], _ P:String){
        
        if (P.elementsEqual("connect") || P.elementsEqual("reconnect")) {
            
            let client = try! connThread(args)
            try! client.connect() {(socket: Socket) in
                
                if socket.isConnected {
                    //
                    client.rawREQ[8]="";//reset LOCKUI
                    client.rawREQ[2]=P;
                    //
                    addNewDevice(DEV:client)
                    //
                }else{//error
                    //
                    if(!args[3].elementsEqual("-1") && args[8].elementsEqual("")) {
                        //
                        args[8]="LOCKUI";
                        //
                        var line=args[0] + Txt.ascii2S(3) + args[2] + Txt.ascii2S(31) +  "CONN_STA" + Txt.ascii2S( 4) + "offline" + Txt.ascii2S(4) + String("0")
                        line=String(format: "dopostqueue['%@']('%@')",args[3] ,line)
                        //
                        self.RST_2_UI(line)
                    }
                    //
                    if (P.elementsEqual("reconnect")){
                        lstDIE(args,2);
                        //disable callback UI
                        //args[3]="-1";
                        //
                    }else if (P.elementsEqual("connect")){
                        //disable callback UI
                        //args[3]="-1";
                        //
                    };
                }
            }
        }else if (P.elementsEqual("disconn")){
            lstDIE(args,1);
            load_DEV_info(1,args);//remove
        }
    }
    
    func addNewDevice(DEV: connThread) {
        // Add the new socket to the list of connected sockets...
        socketLockQueue.sync { [unowned self, DEV] in
            liveLIST.append(DEV)
        }
        
        // Get the global concurrent queue...
        let queue  = DispatchQueue(label: "syncQueue", qos: .utility, attributes: .concurrent)
        
        // Create the run loop work item and dispatch to the default priority global queue...
        queue.async { [unowned self, socket=DEV.socket] in
            
            var shouldKeepRunning = true
            
            var loopK:Int=0
            
            var readData = Data(capacity: AttHandler.bufferSize)
            
            do {

                // Write the welcome string...
                //try socket.write(from: "Hello, type 'QUIT' to end session\nor 'SHUTDOWN' to stop server.\n")
                //
                //
                DEV.sendCMD("cmd=1")
                //let msg="HOLO /connect?cmd=1"
                //try socket.write(from: msg)
                //
                repeat {
                    //
                    let bytesRead = try socket.read(into: &readData)
                    
                    if bytesRead == 0 {
                        //
                        shouldKeepRunning = false//se thoat vong lap
                        loopK=2;//bi may cham cong disconnect
                        break
                        //
                    }else {
                        
                        guard var response = String(data: readData, encoding: .utf8) else {//guard var line = String(data: readData as Data, encoding: .utf8) else {
                            print("Error decoding response...")
                            readData.count = 0
                            break
                        }
                        //
                        print("***** bytesRead: \(bytesRead)" )
                        print("Server received from connection at \(socket.remoteHostname):\(socket.remotePort): \(response) ")
                        
                        let eachLN:[String]=response.spli("\n")
                        for z in 0 ..< eachLN.count {//ignore lastest item.
                            //
                            var line=eachLN[z]
                            if (line==""){
                                continue //**** ko duoc manh dong cho nay, chap nhan di !!!
                            }
                            //
                            line=DEV.CMD(line)//line.replacingOccurrences(of:"\n",with: ""))
                            //
                            //
                            if ((line.elementsEqual("WAI___NXT___LN"))==false){
                                //C$B.onRequestComplete(rawREQ[0] + String.valueOf((char) 3) + step + String.valueOf((char) 31) + line);
                                line=DEV.rawREQ[0] + Txt.ascii2S(3) + DEV.step + Txt.ascii2S(31) + line
                                line=String(format: "dopostqueue['%@']('%@')",DEV.rawREQ[3] ,line)
                                //
                                self.RST_2_UI(line)
                                //
                            }
                            //
                            if (line.elementsEqual("0")){
                                socket.close();
                                loopK=1;//connect ko thanh cong
                                shouldKeepRunning = false
                                break;
                            }
                        }
                        //
                        //
                        if response.hasPrefix(AttHandler.shutdownCommand) {
                            print("Shutdown requested by connection at \(socket.remoteHostname):\(socket.remotePort)")
                            // Shut things down...
                            //self.shutdownServer()
                            return
                        }
                        


                        if response.hasPrefix(AttHandler.quitCommand) || response.hasSuffix(AttHandler.quitCommand) {
                            shouldKeepRunning = false
                        }
                    }
                    
                    readData.count = 0
                    
                } while shouldKeepRunning
                
                
                print("Socket: \(socket.remoteHostname):\(socket.remotePort) closed...")
                socket.close()
       
            }
            catch let error {
                //ben connThread -> sendCMD -> socket.close
                guard let socketError = error as? Socket.Error else {
                    print("Unexpected error by connection at \(socket.remoteHostname):\(socket.remotePort)...")
                    return
                }
                if self.continueRunning {
                    print("Error reported by connection at \(socket.remoteHostname):\(socket.remotePort):\n \(socketError.description)")
                }
                
                //
                //
                if (DEV.step.elementsEqual("disconn") || DEV.step.elementsEqual("connect")) {
                    //remove ra ko add vao lstDIE
                    loopK=1;//connect ko thanh cong
                }else if (loopK==0 && DEV.step.elementsEqual("online")){
                    loopK=2;//trouble network
                }
                
            }
            //
            //(****)
            error_SOK(loopK,DEV);
            //
            //***khac voi android
            if (dieSOCK.count==0 && liveLIST.count==0){
                self.continueRunning = false
                MainApplication.atthwnd=nil//stop
            }
            //
        }//end queue
        
        
    }
    
    
    func error_SOK (_ loopK:Int, _ DEV: connThread ){
        //
        //liveLIST.remove(this);
        self.socketLockQueue.sync { [unowned self, DEV] in
            if let idx = liveLIST.firstIndex(where: { $0 === DEV }) {
                liveLIST.remove(at: idx)
            }
        }
        //
        if (loopK>0){
            do {
                DEV.socket.close();
            } catch {
            }
            
            var line:String=DEV.rawREQ[0] + Txt.ascii2S(3)  + DEV.step   + Txt.ascii2S(31) +
                            "CONN_STA" + Txt.ascii2S(4)  + "offline"  + Txt.ascii2S(4)  + DEV.rawREQ[5]
            //
            line=String(format: "dopostqueue['%@']('%@')",DEV.rawREQ[3] ,line)
            //
            self.RST_2_UI(line)
            //
            lstDIE(DEV.rawREQ,loopK);
            //
        }
    }//end error_SOK
    
    func lstDIE(_ die:[String] ,_ isRMV:Int ){
        //
        if (isRMV==1 && dieSOCK.count==0) {//if (isRMV==1 && dieSOCK.size()==0) {
            return;
        }
        //
        for z in (0 ..< dieSOCK.count).reversed() {// int dog=dieSOCK.size()-1;for (int z=dog;z>-1;z--){
            //
            var raw:[String]=dieSOCK[z];
            //
            if (die[0].elementsEqual(raw[0]) && die[1].elementsEqual(raw[1])){
                //
                if (isRMV==1){//dieSOCK.remove((die));
                    if let idx = dieSOCK.firstIndex(of: die) {
                        dieSOCK.remove(at: idx)
                    }
                }else{
                    //update window handler id
                    raw[3]=die[3];
                }
                //
                //co roi ko add nua ....
                return;
            }
        
        }
        //
        //neu isRMV !=1 thi se add vao dieSOCK
        dieSOCK.append(die);
        //
    }//end lstDIE
    
    func modATT(_ args:[String], _ rawRQ:[String]){
        //
        var rawREQ:[String]=rawRQ.map{$0}
        //
        if (!rawREQ[5].elementsEqual("")) {
            //khi moi load len bi dead...
            //
            var dbK:[String]=rawREQ[5].spli(";");//old msg[7]
            dbK[4] = rawREQ[4]
            rawREQ[5]=dbK.joined(separator:";")
        }
        //
        rawREQ[6]=args[6];//comkey
        rawREQ[7]=args[7];//du phong 1
        rawREQ[8]=args[8];//du phong 2
        rawREQ[9]=args[9];//du phong 9
        //rawREQ[10]=args[10];//10 chua thong tin khac nhau cua tung thiet bi, base64...
        //
        load_DEV_info(2,rawREQ);//add

        //tra ve lenh connect
        var line=args[0] + Txt.ascii2S(3) + args[2]   + Txt.ascii2S(31) +
        "CONN_STA" + Txt.ascii2S(4)  +  args[2]  + Txt.ascii2S(4)  + rawREQ[5]
        line=String(format: "dopostqueue['%@']('%@')",args[3] ,line)
        self.RST_2_UI(line)
    }

}
