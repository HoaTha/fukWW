//
//  Utils.swift
//  AppHrm
//
//  Created by Administrator on 11/01/2024.
//

import Foundation

public extension String {
    /*
    let text = "www.stackoverflow.com"
    let at = text.character(3) // .
    let range = text.substring(0..<3) // www
    let from = text.substring(from: 4) // stackoverflow.com
    let to = text.substring(to: 16) // www.stackoverflow
    let between = text.between(".", ".") // stackoverflow
    let substringToLastIndexOfChar = text.lastIndexOfCharacter(".") // 17
    */
    
    //right is the first encountered string after left
    func between(_ left: String, _ right: String) -> String? {
        guard
            let leftRange = range(of: left), let rightRange = range(of: right, options: .backwards)
            , leftRange.upperBound <= rightRange.lowerBound
            else { return nil }
        
        let sub = self[leftRange.upperBound...]
        let closestToLeftRange = sub.range(of: right)!
        return String(sub[..<closestToLeftRange.lowerBound])
    }
    
    var length: Int {
        get {
            return self.count
        }
    }
    
    func substring(to : Int) -> String {
        let toIndex = self.index(self.startIndex, offsetBy: to)
        return String(self[...toIndex])
    }
    
    func substring(from : Int) -> String {
        let fromIndex = self.index(self.startIndex, offsetBy: from)
        return String(self[fromIndex...])
    }
    
    func substring(_ r: Range<Int>) -> String {
        let fromIndex = self.index(self.startIndex, offsetBy: r.lowerBound)
        let toIndex = self.index(self.startIndex, offsetBy: r.upperBound)
        let indexRange = Range<String.Index>(uncheckedBounds: (lower: fromIndex, upper: toIndex))
        return String(self[indexRange])
    }
    
    func character(_ at: Int) -> Character {
        return self[self.index(self.startIndex, offsetBy: at)]
    }
    
    func lastIndexOfCharacter(_ c: Character) -> Int? {
        guard let index = range(of: String(c), options: .backwards)?.lowerBound else
        { return nil }
        return distance(from: startIndex, to: index)
    }
    
    func spli( _ spe:String) -> [String]{
        return self.components(separatedBy:spe)
    }

    
    func base64ToByteArray() -> [UInt8]? {
        if let nsdata = NSData(base64Encoded: self, options: .ignoreUnknownCharacters) {
            var bytes = [UInt8](repeating: 0, count: nsdata.length)
              nsdata.getBytes(&bytes)
              return bytes
          }
          // Invalid input
          return nil
    }
    func urlEncoded() -> String? {
        return self.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)?
            .replacingOccurrences(of: "&", with: "%26")
    }
    
}


class Txt {
    
    public static func ascii2C(_ val:Int) -> Character{
        //let value = 4
        // Convert Int to a UnicodeScalar.
        //let u = UnicodeScalar(value)!
        // Convert UnicodeScalar to a Character.
        //let char = Character(u)
        
        return Character(UnicodeScalar(val)!)
    }
    public static func ascii2S(_ val:Int) -> String{
        //let value = 4
        // Convert Int to a UnicodeScalar.
        //let u = UnicodeScalar(value)!
        // Convert UnicodeScalar to a Character.
        //let char = Character(u)
        return String(ascii2C(val))
    }
    
    public static func sformat(_ a:String...)->String{
        
        var s:[String]=a[0].spli(a[1])
        
        for i in 0 ..< s.count-1 {//keep lastest index
            if (a.count>i+2){
                s[i]+=a[i+2]
            }
        }
        
        
        return s.joined(separator: "")
        
    }
    public static func sformat(_ o:String, _ f:String, _ v:[String])->String{
        
        var s:[String]=o.spli(f)
        
        for i in 0 ..< s.count-1 {//keep lastest index
            if (v.count>i){
                s[i]+=v[i]
            }
        }

        return s.joined(separator: "")
        
    }
    
}
