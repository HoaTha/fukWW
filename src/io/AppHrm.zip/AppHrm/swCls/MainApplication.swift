//
//  MainApplication.swift
//  AppHrm
//
//  Created by Administrator on 12/01/2024.
//
import AVFoundation

class MainApplication: NSObject {
    
    class var firebase_topic: String { "" }
    
    static var atthwnd:AttHandler?
    
    static func AttDeviceService(_ dev:[String]){
        //
        if (atthwnd==nil){
            let port = 1337
            atthwnd = AttHandler()
            print("Swift Echo Server Sample")
            print("Connect with a command line window by entering 'telnet ::1 \(port)'")
            atthwnd?.run()
        }
        //
        if dev.count>0 {
            atthwnd?.INI_CONN(dev)//postJSON. MSG_2_ATTDEV (-994,dev,1);
        }
        //
    }
    
    static func att_device(){
        //

        let lstMCC:[String]=TinyDB.getListString("lst__MCC")// + MainApplication.firebase_topic)
        //
        if (lstMCC.count>0){
            //
            AttDeviceService([])
            //
            for dev in lstMCC {
                atthwnd?.INI_CONN(dev.spli(Txt.ascii2S(30)))//postJSON. MSG_2_ATTDEV (-994,dev,1);
            }
        }
        //
    }
    
    static func RTEV(_ args:[String] )->Int{//functio nay viet 2 lan
        if (args.count<4) {
            return 0
        }
        //
        let arg_4:[String]=args[4].spli(",");
        
        if let idx = arg_4.firstIndex(of: "[1") {
            if (idx==0){
                return 1
            }else{
                return 0
            }
        }else{
            return 0
        }
    }
    
    
    static var audioPlayer: AVAudioPlayer!
    
    static func playAudioAsset(_ assetName : String) {

       guard let audioData = NSDataAsset(name: assetName)?.data else {
          fatalError("Unable to find asset \(assetName)")
       }

       do {
          audioPlayer = try AVAudioPlayer(data: audioData)
          audioPlayer.play()
       } catch {
          fatalError(error.localizedDescription)
       }
    }
    
}
