//
//  TinyDB.swift
//  AppHrm
//
//  Created by Administrator on 12/01/2024.
//
//https://github.com/kcochibili/TinyDB--Android-Shared-Preferences-Turbo/blob/master/TinyDB.java
import Foundation
class TinyDB {
    
    static func  getListString(_ key:String)->[String]{
        let val=UserDefaults.standard.string(forKey:key)
        if val == nil {
            return []
        }
        return val!.spli( "‚‗‚")
    }
    
    static func putListString(_ key:String , _ stringList:[String] ) {
        if (stringList.count>0){
            UserDefaults.standard.set(stringList.joined(separator:"‚‗‚"), forKey: key)
        }else{
            UserDefaults.standard.removeObject(forKey: key)
        }
        UserDefaults.standard.synchronize()
    }
    
}
