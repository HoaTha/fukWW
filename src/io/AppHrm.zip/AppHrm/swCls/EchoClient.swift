//
//  EchoClient.swift
//  AppHrm
//
//  Created by Administrator on 11/01/2024.
//

import Socket

class EchoClient {
    
    let port: Int32
    let host: String
    let socket: Socket
    var cdvArg: NSArray
    
    
    var rawREQ:[String]=[]
    var OCL:[String]=[]

    init(_ cdvArg:NSArray) throws {
        
        self.cdvArg=cdvArg
        
        self.host =  String(describing: cdvArg[1])
        
        self.port = 11222
        
        self.socket = try Socket.create()
        
    }

    func connect(handler: (_ socket: Socket) -> Void) throws {
        
        //host: "192.168.1.201" ,port: port
        
        try socket.connect(to: host, port: port)
        
        handler(socket)
        
    }
    
    
    func OCL_BUILDER(_ moi:String ,_ dbK_4:String ) -> [String]{
        //build cac thong so interger giong nhu hihrs
        var OCL:[String]=dbK_4.substring(1..<dbK_4.length).spli(",");//OCL=dbK_4.substring(1,dbK_4.length()-1).split(",",-1);
        //
        let rawREQ_4:[String]=moi.substring(1..<moi.length).spli(",");//String[] rawREQ_4 =moi.substring(1,moi.length()-1).split(",",-1);
        
        for i in 0 ..< rawREQ_4.count {
            OCL[i]=rawREQ_4[i];
        }
        
        return OCL;
    }
    
    func GIAI_MA(_ org:String) ->String{
        let SECRET:String  = "My32charPasswordAndInitVectorStr"//must be 32 char length
        let iv:String=SECRET.substring(0..<16)
        //https://jaysojitra13.medium.com/cross-platform-encryption-and-decryption-using-android-ios-angular-noejs-38bc4f75eaf6
        return postJSON.decrypt(org,iv ,SECRET,"AES/CBC/NoPadding")
    }
    
    func part_DEV(_ line:String) -> [String] {
        

        let msg=line.spli( Txt.ascii2S(4))//.components(separatedBy:  Txt.ascii2S(4))
        
        //-1 after split will keep all null item ....
        let dbK = msg[7].spli(";");//old msg[7]
        //
        //
        //String org = dbK[1].replaceAll("_", "/").replaceAll("-", "+");
        let org:String = dbK[1].replacingOccurrences(of: "_", with: "/").replacingOccurrences(of: "-", with: "+")
        //
        //
        var RAW:String=GIAI_MA(org);
        
        //dao thu tu thong tin
        let mark:String=RAW.substring(0..<3);
        RAW=RAW.substring(from:3);//please remove 3 char mark !
        //
        //
        let TOK:[String]=RAW.replacingOccurrences(of:"\\n",with: "").spli(Txt.ascii2S(29));
        //
        var RST:[String] = TOK.map { $0 };//ArrayList<String> RST= new ArrayList<String>(Arrays.asList(TOK));
        //
        for i in 0 ..< mark.length {
            let c = Int(String(mark.character(i))) ?? 0
            RST[c]=TOK[i]
        }
        //
        //lay duoc seri no ...
        let SN:String=RST[0];
        let MAC:String=msg[6].spli("=")[1]//String MAC= msg[6].split("=")[1];//.replaceAll(":","")

        //OCL= OCL_BUILDER(rawREQ[4],dbK[4]);
        
        //dbK[4]="[" + postJSON.fukJOIN(OCL,",") + "]";
        //array.joined(separator: ", ")
        
        return msg;
        
        //String[] msg=line.split(String.valueOf((char) 4));
        //return [1, 2, 3]
    }
    
    
    
}
