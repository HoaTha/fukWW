#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Cordova/CDVViewController.h>

@interface FCCHead : NSObject

@property (strong, nonatomic) id someProperty;
@property (nullable, nonatomic, strong) IBOutlet CDVViewController* _self;

- (void) someMethod;
- (void) handleTap;

- (NSString*)pathForResource:(NSString*)resourcepath;

@end

