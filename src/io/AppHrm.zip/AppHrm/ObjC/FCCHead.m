//
//  CustomObject.m
//  olalaswift
//
//  Created by Administrator on 05/01/2024.
//

#import <Foundation/Foundation.h>
#import "FCCHead.h"
#import <FCChatHeads/FCChatHeads.h>

#import <UIKit/UIKit.h>
#import <Cordova/CDV.h>
#import <Cordova/CDVWebViewEngineProtocol.h>

#import "fukWW.h"

@interface FCCHead () <FCChatHeadsControllerDatasource>
{
    NSUInteger _index;
    BOOL _chatHeadsShown;
    NSUInteger _unreadCount;
    BOOL _stopBombarding;
    
    NSArray *_imageNames;
    NSArray *_displayTexts;
}

@end

@implementation FCCHead

- (void) someMethod {
    NSLog(@"SomeMethod Ran");

  
    _imageNames = @[@"costanza", @"einstein", @"letterman", @"nigella", @"steve", @"trump"];
    _displayTexts = @[@"\"I'm much more comfortable criticizing people behind their backs.\"", @"\"Two things are infinite: the universe and human stupidity... and I'm not so sure about the universe.\"", @"\"I'm just trying to make a smudge on the collective unconscious.\"", @"\"I don't believe in low fat coooking.\"", @"\"I want to put a ding in the universe.\"", @"\"I know words, I have the best words. I have the best, but there is no better word than stupid.\""];
    
   
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    tapGesture.numberOfTapsRequired = 2;
    tapGesture.numberOfTouchesRequired = 1;
    
    [self._self.view addGestureRecognizer:tapGesture];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongTap:)];
    
    [self._self.view addGestureRecognizer:longPress];
    
    
    
    ChatHeadsController.datasource = self;
    
}




- (void)handleTap
{
    _stopBombarding = YES;
    
    switch (_index%2) {
        case 0: {
            // Presenting with image
            NSString *imageName = _imageNames[_index%6];
            
            [ChatHeadsController presentChatHeadWithImage:[UIImage imageNamed:imageName] chatID:imageName];
            [ChatHeadsController setUnreadCount:_unreadCount++ forChatHeadWithChatID:imageName];
            
            _index++;
        }
            break;
            
        case 1: {
            // Presenting with view
            
            NSString *imageName = _imageNames[_index%6];
            
            UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
            imageView.frame = DEFAULT_CHAT_HEAD_FRAME;
            imageView.layer.cornerRadius = CGRectGetHeight(imageView.bounds)/2;
            imageView.clipsToBounds = YES;
            
            [ChatHeadsController presentChatHeadWithView:imageView chatID:imageName];
            [ChatHeadsController setUnreadCount:_unreadCount++ forChatHeadWithChatID:imageName];
            
            _index++;
        }
            break;
            
            
        default:
            break;
    }
}


- (void)handleLongTap:(UILongPressGestureRecognizer *)longPress
{
    if (longPress.state == UIGestureRecognizerStateBegan)
    {
        if (_chatHeadsShown)
        {
            _chatHeadsShown = NO;
            
            [ChatHeadsController dismissAllChatHeads:YES];
        }
        else
        {
            _chatHeadsShown = YES;
            
            NSMutableArray *chatHeads = [NSMutableArray array];
            
            for (int count = 0; count < 3; count++)
            {
                NSString *imageName = _imageNames[count];
                
                UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
                imageView.frame = DEFAULT_CHAT_HEAD_FRAME;
                imageView.layer.cornerRadius = CGRectGetHeight(imageView.bounds)/2;
                imageView.layer.masksToBounds = YES;
                
                FCChatHead *chatHead = [FCChatHead chatHeadWithView:imageView
                                                             chatID:imageName
                                                           delegate:ChatHeadsController];
                
                [chatHeads addObject:chatHead];
            }
            
            [ChatHeadsController presentChatHeads:chatHeads animated:YES];
        }
    }
}

- (UIView *)chatHeadsController:(FCChatHeadsController *)chatHeadsController viewForPopoverForChatHeadWithChatID:(NSString *)chatID
{
    

    /*
    UIView *view = [[UIView alloc] initWithFrame:self._self.view.bounds];
    [view setBackgroundColor:[UIColor whiteColor]];
    
    UILabel *displayText = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, view.bounds.size.width - 40, view.bounds.size.height - 100)];
    displayText.font = [UIFont systemFontOfSize:17.0];
    displayText.numberOfLines = 0;
    displayText.textColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    displayText.textAlignment = NSTextAlignmentCenter;
//    displayText.shadowColor = [UIColor colorWithWhite:0.6 alpha:0.7];
    
    displayText.text = _displayTexts[[_imageNames indexOfObject:chatID]];
    
    [view addSubview:displayText];
    
    return view;
     */
    // Do any additional setup after loading the view, typically from a nib.
    
    //(NSString*)resourcepath = pathForResource;

    //UIView* engineWebView [[CDVWebViewEngine. alloc]init]
    //WKWebView *webView = [[WKWebView alloc]init];
    
    NSString *urlString = @"index1.html";
    NSString* startFilePath=[self pathForResource:urlString];
   
    //NSURL *url = [NSURL URLWithString:startFilePath];
    NSURL *url = [NSURL fileURLWithPath:startFilePath];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    
    fukWW *fuk=[[fukWW alloc] initWithFrame:self._self.view.bounds];
    fuk.commandDelegate=self._self.commandDelegate;
    
    [fuk pluginInitialize];
    [fuk loadRequest:urlRequest];
    //return [fuk viewDidLoad:self._self.view.bounds fURL:startFilePath];
    return [fuk webView];
    
    
    /*
    NSString* errorHtml = @"<!doctype html>"
                            @"<script src='http://192.168.1.91:5114/docs/jslocal/apphrm_ol.js'></script>";
    [webView loadHTMLString:errorHtml baseURL:nil];
     */
    WKWebView *webView = [[WKWebView alloc]init];
    return webView;
}



- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}



- (NSString*)pathForResource:(NSString*)resourcepath
{
    NSBundle* mainBundle = [NSBundle mainBundle];
    NSMutableArray* directoryParts = [NSMutableArray arrayWithArray:[resourcepath componentsSeparatedByString:@"/"]];
    NSString* filename = [directoryParts lastObject];

    [directoryParts removeLastObject];

    NSString* directoryPartsJoined = [directoryParts componentsJoinedByString:@"/"];
    NSString* directoryStr = @"www";

    if ([directoryPartsJoined length] > 0) {
        directoryStr = [NSString stringWithFormat:@"%@/%@", directoryStr, [directoryParts componentsJoinedByString:@"/"]];
    }

    return [mainBundle pathForResource:filename ofType:@"" inDirectory:directoryStr];
}

@end
