//
//  AppDelegate.swift
//  olalaswift
//
//  Created by Administrator on 05/01/2024.
//
import Foundation
import UIKit
import Cordova
import Network

import Socket

@main
class AppDelegate:  CDVAppDelegate {
    
    static var  stash = Stash()
    static var  generator = _Generator(stash: stash, count:0, interval: 2.0)
    //static var  work = _Work(stash: stash, count: 5)

    
    override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        //
        self.viewController = ViewController()
        //
        
        MainApplication.att_device()
        //
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
 
    func evalJsHelper2(_ js: String?) {

        self.viewController?.commandDelegate.evalJs(js,scheduledOnRunLoop: false)
        
    }
    
    func dume(_ dog:Bool){
        
    }
    @objc func cdv_bridge(_ cdvArg: NSArray ) -> String{
        

        print(Car.countryOfProduction)
        print(Car.topSpeed)
        
        print(SuperFastCar.countryOfProduction)
        print(SuperFastCar.topSpeed)
        
        /*
        let result = CDVPluginResult(
                    status: CDVCommandStatus_OK,
                    messageAs: "A")

        self.viewController?.commandDelegate.send(result, callbackId: "command?.callbackId")
         */
        



        
        if (cdvArg[0] as? String=="ATT_DEV_CONN"){
        
            let localNetworkPrivacy = LocalNetworkAuthorization()
            localNetworkPrivacy.requestAuthorization { doggy in
                if (doggy==true){
                    var args:[String]=cdvArg.compactMap({ $0 as? String })
                    args.remove(at: 0)//item 0="ATT_DEV_CONN"
                    MainApplication.AttDeviceService(args)
                }else{
                    //xy ly sau, gio ban qua !!!
                }
            }


            

            
            
            //sokBLUE()
            
            //var  js = String(format: "dopostqueue['%@']('%@')",arg[4] as! String ,"val")
            //evalJsHelper2(js)
            
            /*
            //AppDelegate.generator.addChip()
            //https://developer.apple.com/forums/thread/84472
            
            //https://forums.developer.apple.com/forums/thread/120486
            //https://forums.developer.apple.com/forums/thread/120486
            
            //https://forums.developer.apple.com/forums/thread/705328
            //https://gist.github.com/ruurdadema/8954b39853b97babed6c62297712b1af
            let  connection: NWConnection?
            //let  listener: NWListener?
            let  host: NWEndpoint.Host = NWEndpoint.Host( String(describing: "192.168.1.201"))  //
            let  port: NWEndpoint.Port = 11222
            //let myport: NWEndpoint.Port = 0
            let  params_out = NWParameters.tcp
            //let  params_in = NWParameters.tcp
            
            connection = NWConnection(host: host, port: port, using: params_out)
            let tcp=NetworkConnection(nwConnection: connection!,cdvArg)
            let queue: DispatchQueue = DispatchQueue(label: "syncQueue", qos: .utility, attributes: .concurrent)
            tcp.start(queue: queue)
            */
            //tcp.close()
          
       
            /*
            let queue: DispatchQueue = DispatchQueue(label: "syncQueue", qos: .utility, attributes: .concurrent)
            queue.async(flags: .barrier) { [unowned self] in
                let conn=SocketDataManager()
                conn.connectWith()
            }
             */
            
        }
        
        return "DU ME MAY"
        
    }
    

 
}
/*
//https://www.agnosticdev.com/blog-entry/swift-networking/networkconnectivity-swift-package-connectivity-state
extension ViewController: NetworkConnectionDelegate {
 
    func connectionReceivedData(connection: NetworkConnection, data: Data){
        var dog:String=""
        var dogx:String=""
    }
}
*/

/*

@main
class AppDelegate: CDVAppDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}
 
 */

