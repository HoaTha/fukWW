//
//  ViewController.swift
//  olalaswift
//
//  Created by Administrator on 05/01/2024.
//

import UIKit
import Cordova
import BackgroundTasks


class ViewController: CDVViewController {
    
    var  instanceOfCustomObject:FCCHead?

    override func viewDidLoad() {
        
        //AppDelegate.generator.start()
        //AppDelegate.work.start()
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        


        
      
        instanceOfCustomObject = FCCHead()
        instanceOfCustomObject?.someProperty = "Hello World"
        print(instanceOfCustomObject?.someProperty)
        
        instanceOfCustomObject?._self=self
        
        instanceOfCustomObject?.someMethod()
        
        //registerBackgroundTasks()
        

    }
    
    
    /// 앱의 launch sequence가 끝나기 전에 Background Task를 Scheduler에 "등록"해야 합니다.
   /// Info.plist에 등록한 키 값으로 등록해야 합니다.
   private func registerBackgroundTasks() {
       
       print("Background Task 등록!")
       // RefreshTask
       // 1. Refresh Task 등록
       let taskIdentifier = ["ch.blah.refresh"]
       BGTaskScheduler.shared.register(forTaskWithIdentifier: taskIdentifier[0], using: nil, launchHandler: { task in
           // 2. 실제로 수행할 Background 동작 구현
           self.handleBackgroundTask(task: task as! BGAppRefreshTask)
       })
   }
    
    private func handleBackgroundTask(task: BGAppRefreshTask) {
         
         task.expirationHandler = {
             task.setTaskCompleted(success: false)
         }
         
         Task {
             do {
                 let url = URL(string: "https://baconipsum.com/api/?type=all-meat&paras=1&start-with-lorem=1")!
                 let request = URLRequest(url: url)
                 async let (data, response) = URLSession.shared.data(for: request)
                 guard try await (response as? HTTPURLResponse)?.statusCode == 200 else {
                     print("HyunndyError.badNetwork 성공!! \n")
                     return
                 }
                 
                 let paragraph = try JSONDecoder().decode([String].self, from: try await data)
                 print("BackgroundTask 성공!! \n\(paragraph[0])")
                 task.setTaskCompleted(success: true)
             } catch {
                 task.setTaskCompleted(success: false)
             }

         }
     }
    
    
    private func scheduleBackgroundTask() {
           let task = BGAppRefreshTaskRequest(identifier: "ch.blah.refresh")
           /// (Processing Task 였다면)
           /*
            task.requiresExternalPower = false // 배터리를 사용할 것인지 여부
           task.requiresNetworkConnectivity = false // 네트워크를 사용할 것인지 여부
            */
           
           // 백그라운드 작업을 실행할 때까지의 최소 대기 시간
           task.earliestBeginDate = Date(timeIntervalSinceNow: 1 * 60)
           
           do {
               print("Background Task submit!")
               // Background Task 등록!!
               try BGTaskScheduler.shared.submit(task)
           } catch {
               print("Could not schedule app refesh")
           }
       }
    

    
    
    
    /*
    //https://viblo.asia/p/ios-swift-view-controller-life-cycle-RQqKLYymZ7z
    @IBAction func goToXanh(_ sender: Any) {
         let sb = UIStoryboard(name: "Main", bundle: nil)
         let manHinhXanh = sb.instantiateViewController(withIdentifier: "MauXanhViewController") as! MauXanhViewController
         self.navigationController?.pushViewController(manHinhXanh, animated: true)
     }
     */
     
     override func viewWillAppear(_ animated: Bool) {
         print("Man Hinh 1 : viewWillAppear")
     }
     
     override func viewDidAppear(_ animated: Bool) {
         print("Man Hinh 1 : viewDidAppear")
         //scheduleBackgroundTask()
         
     }
     
     override func viewWillDisappear(_ animated: Bool) {
         print("Man Hinh 1 : viewWillDisappear")
     }
     

     override func viewDidDisappear(_ animated: Bool) {
         print("Man Hinh 1 : viewWillDisappear")
        // Do my background stuff
    }
    
    //cordova CDVControler
    @objc func dume_taomet(){
    
        print("\nHello User!")
    }
    
    //https://stackoverflow.com/questions/1018195/objective-c-calling-selectors-with-multiple-arguments
    @objc func greetUserx(_ dog: NSArray ){
        print("\nHello User!")
        instanceOfCustomObject?.handleTap()
        
        
        print(Car.countryOfProduction)
        print(Car.topSpeed)
        
        print(SuperFastCar.countryOfProduction)
        print(SuperFastCar.topSpeed)
    }
    
    




}

